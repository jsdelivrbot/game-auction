(function(window) {
	window.__env = window.__env || {};

	// API urls
	window.__env.apiUrl = '/api';
	window.__env.apiAuthUrl = '/auth';
}(this));
